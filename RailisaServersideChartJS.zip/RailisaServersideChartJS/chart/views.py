from datetime import date, datetime
from chartjs.colors import next_color, COLORS
from chartjs.views import JSONView
from chartjs.views.lines import BaseLineChartView
from django.http import JsonResponse, request
from django.views.generic import FormView
from django.views.generic.base import TemplateView
from django_extensions.db.fields import json
from consultation.models import Company, Country, Value, Domain, Variable, ValueMonthly,Region
from .forms import SelectionVariableList
from .util import range_all_months_in_period


def load_country(request, rgn_id=None):
    rgn_id = request.GET.get('rgn_id', '')
    countries = Country.objects.filter(rgn_id=rgn_id).order_by('rgn_id', 'ctry_name')
    countrie_dict = {x.ctry_id: x.dispaly_ctry_name for x in countries}
    return JsonResponse(countrie_dict)

def load_company_by_ctry_id(request, ctry_id=None):
    """ """
    ctry_id = request.GET.get('ctry_id', '')
    companies = Company.objects.filter(ctry_id=ctry_id).order_by( 'co_cf_code')
    companies_dict = {str(x.co_id) + '_': x.display_co_name for x in companies}
    return JsonResponse(companies_dict)

class Home(TemplateView):
    template_name = 'index.html'

def load_variable_by_type_value(request):
    dom_id=request.GET.get('dom_id',"")
    type_value=request.GET.get('type_value',"")
    select_domain = list(map(str.strip, dom_id.split(',')))
    variable_dict = {}
    variable_autorise=[]
    variables = Variable.objects.filter(dom_id__in=select_domain).order_by('dom_id')
    if type_value=="mois":
        variable_autorise=ValueMonthly.objects.values("var_id").distinct()
    elif (type_value=="annee"):
        variable_autorise=Value.objects.values("var_id").distinct()
    for variable in variables:
        for v in variable_autorise:
            if variable.var_id ==v["var_id"]:
                variable_dict[variable.var_id] = variable.__str__()
    return JsonResponse(variable_dict)

class ChartForMultipleVariables(TemplateView):
    template_name = 'chart_statistics.html'
    def get_context_data(self, **kwargs):
        context = super(ChartForMultipleVariables, self).get_context_data(**kwargs)
        form = SelectionVariableList(self.request.POST or None)
        context["form"] = form
        return context

class ChartForMultipleVariablesJSONView(BaseLineChartView):
    axis = []
    labels = []
    providers = []
    res = []
    var_id = None
    co_id=None
    val_sel = None
    vs = None
    period_start=None
    period_end=None
    type_value=None

    def get_labels(self):
        """ Return last 5 years as labels for the x-axis."""
        try:
            vs = str(self.request.GET.get('var_id', ''))     
            self.var_id = [x for x in vs.split(",")]
            self.period_start = self.request.GET.get('period_start', '')
            self.period_end = self.request.GET.get('period_end', '')
            self.type_value = self.request.GET.get('type_value', '')
        except Exception as e:
            print(e)
        if self.type_value is not None :
            if self.type_value == "annee":
                self.labels = [dt for dt in range(int(self.period_start),int(self.period_end)+1)]
            elif self.type_value=="mois":  
                self.labels=range_all_months_in_period(self.period_start, self.period_end,"%Y-%m")   
        else:
            self.labels = ['year1', 'year2', 'year3', 'year4', 'year5']
        return self.labels

    def get_providers(self):
        try:
            vs = str(self.request.GET.get('var_id', ''))     
            if vs != '':
                self.var_id = [x for x in vs.split(",")]
            else:
                self.var_id = ['', '']
        except Exception as e:
            print(e)
        variables=Variable.objects.filter(var_id__in=self.var_id).order_by('var_id')
        for variable in variables:
            self.providers.append(variable.var_full_name)
        return self.providers

    def get_data(self):
        try:
            self.co_id = str(self.request.GET.get('co_id', ''))
            vs = str(self.request.GET.get('var_id', ''))
            self.var_id = [x for x in vs.split(",")]
        except Exception as e:
            print(e)

        if self.var_id is not None and self.co_id is not None and self.type_value is not None:          
            self.res = []
            for variable in self.var_id:
                data=[]
                if self.type_value=="annee":
                    cpy=Value.objects.values('val_data','val_year').filter(var_id=variable,co_id=self.co_id).order_by('val_year')
                    for annee in self.labels:
                        trouve=False
                        for value in cpy:
                            if value['val_year']==annee:
                                data.append(value['val_data'])
                                trouve=True
                                break
                        if trouve==False:
                            data.append([])
                elif self.type_value=="mois":
                    cpy=ValueMonthly.objects.values('val_data','val_month_date').filter(var_id=variable,co_id=self.co_id).order_by('val_month_date')
                    for mois in self.labels:
                        trouve=False
                        for value in cpy:
                            if value['val_month_date'].strftime("%Y-%m")==mois:
                                data.append(value['val_data'])
                                trouve=True
                                break
                        if trouve==False:
                            data.append([])                    
                self.res.append(data)
        else:
            self.res = [[0, 0, 0, 0, 0]]
        return self.res

    def get_colors(self):
        colors = (
            (88, 214, 141), 
            (52, 152, 219),  
        )
        return next_color(colors)

    def get_axis(self):
        self.axis = ['y-axis-1']
        return self.axis

    def get_dataset_options(self, index, color):
        default_opt = {
            "backgroundColor": "rgba(%d, %d, %d, 0.5)" % color,
            "borderColor": "rgba(%d, %d, %d, 1)" % color,
            "pointBackgroundColor": "rgba(%d, %d, %d, 1)" % color,
            "pointBorderColor": "#fff",
            "fill": "false",
        }
        return default_opt

def count_result(request):
    select_period=request.GET.get('type_value','')
    select_dom_id = request.GET.get('dom_id', '')
    select_dom_id = list(map(str.strip, select_dom_id.split(',')))
    select_var_id = request.GET.get('var_id', '') 
    select_var_id= list(map(str.strip, select_var_id.split(',')))
    select_date_start = request.GET.get('date_start', '') 
    select_date_end = request.GET.get('date_end', '') 
    select_region = request.GET.get('rgn_id', '')     
    select_country = request.GET.get('ctry_id', '')  
    select_company = request.GET.get('co_id', '')  
    result = {}
    if select_period=="mois":
        qs = ValueMonthly.objects.all()
        qs = qs.select_related('co_id', 'var_id', 'ctry_id', 'ctry_id__rgn_id', 'var_id__dom_id')
        qs = qs.order_by('var_id', 'ctry_id__rgn_id', 'ctry_id', 'co_id', 'val_month_date')
        if not select_dom_id ==['']:
            qs = qs.filter(var_id__dom_id__in=select_dom_id)
        if not select_var_id==['']:
            qs = qs.filter(var_id__in=select_var_id)
        if not select_date_start=='undefined':
            qs = qs.filter(val_month_date__gte=datetime.strptime(select_date_start, "%Y-%m"))
        if not select_date_end=='undefined':
            qs = qs.filter(val_month_date__lte=datetime.strptime(select_date_end, "%Y-%m"))
        if not select_region == '':
            countries=Country.objects.filter(rgn_id=select_region).order_by('rgn_id__rgn_name', 'ctry_name')
            qs = qs.filter(ctry_id__in=countries)
        if not select_country == '':
            qs = qs.filter(ctry_id=select_country)
        if not select_company == '':
            qs = qs.filter(co_id=select_company)
    elif select_period=="annee":
        qs = Value.objects.all()
        qs = qs.select_related('co_id', 'var_id', 'ctry_id', 'ctry_id__rgn_id', 'var_id__dom_id')
        qs = qs.order_by('var_id', 'ctry_id__rgn_id', 'ctry_id', 'co_id', 'val_year')
        if not select_dom_id ==['']:
            qs = qs.filter(var_id__dom_id__in=select_dom_id)
        if not select_var_id==['']:
            qs = qs.filter(var_id__in=select_var_id)
        if not select_date_start=='undefined':
            qs = qs.filter(val_year__gte=select_date_start)
        if not select_date_end=='undefined':
            qs = qs.filter(val_year__lte=select_date_end)
        if not select_region == '':
            countries=Country.objects.filter(rgn_id=select_region).order_by('rgn_id__rgn_name', 'ctry_name')
            qs = qs.filter(ctry_id__in=countries)
        if not select_country == '':
            qs = qs.filter(ctry_id=select_country)
        if not select_company == '':
            qs = qs.filter(co_id=select_company)
    result['count'] = int(qs.count())
    return JsonResponse(result)

