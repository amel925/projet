import datetime
from dateutil.relativedelta import relativedelta


def range_all_months_in_period(start_date, end_date,date_format):
    result = []
    s_date = datetime.datetime.strptime(start_date, date_format)
    print("*********1: ",s_date)
    e_date = datetime.datetime.strptime(end_date,date_format)
    while s_date <= e_date:
        result.append(datetime.datetime.strftime(s_date,date_format))
        
        s_date += relativedelta(months=1)
    #print("********3 : ",s_date)
    return result

