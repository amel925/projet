from django.conf.urls import url
from django.views.generic import TemplateView
from .views import   load_country, ChartForMultipleVariables,ChartForMultipleVariablesJSONView,load_variable_by_type_value,count_result,load_company_by_ctry_id

home = TemplateView.as_view(template_name="index.html")

urlpatterns = [
    url(r'^$', home, name='home'),
    url(r'^load_variable_by_type_value/$', load_variable_by_type_value, name='load_variable_by_type_value'),
    url(r'^load_country/$', load_country, name='load_country'),
    url(r'^load_company_by_ctry_id/$', load_company_by_ctry_id, name='load_company_by_ctry_id'),
    url(r'^chart_multiple_variables/$', ChartForMultipleVariables.as_view(), name='chart_multiple_variables'),
    url(r'^chart_multiple_variables/json', ChartForMultipleVariablesJSONView.as_view(), name='chart_multiple_variables_json'),
    url(r'^count_result/$', count_result, name='count_result'),
]