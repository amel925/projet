from datetime import date, datetime
from django import forms
from bootstrap_datepicker_plus import YearPickerInput,MonthPickerInput
from consultation.models import Country, Company, Region, Domain, Variable, ValueMonthly

class SelectionVariableList(forms.Form):

    DOMAIN_CHOICE =[(x.dom_id,x.dom_name) for x in Domain.objects.all().order_by('dom_name')]
    VARIABLE_CHOICES =  [(x.var_id, x.variable) for x in Variable.objects.all().order_by('var_id')]

    REGION_CHOICE = [('', 'Select a region')] +[(x.rgn_id, x.dispaly_rgn_name) for x in Region.objects.all().order_by('rgn_id')]
    COUNTRY_CHOICE = [('', 'Select a country')] +[(x.ctry_id, x.dispaly_ctry_name) for x in Country.objects.all().order_by('ctry_id')]
    COMPANY_CHOICE = [('', 'Select a company')] +[(x.co_id, x.display_co_name) for x in Company.objects.all().order_by('ctry_id', 'co_cf_code')]

    domain = forms.ChoiceField(choices=DOMAIN_CHOICE, widget=forms.SelectMultiple(attrs={'title': 'Select Domain',
                                                                                 'style': 'width : 100%;',
                                                                                 'id': 'widget_domain',
                                                                                 'onchange': 'domain_changed();'}))

    variable = forms.ChoiceField(widget=forms.SelectMultiple(attrs={'title': 'Select variable',
                                                            'style': 'width : 100%;',
                                                            'id': 'widget_variable',
                                                            'onchange': 'variable_changed();'}))
    regions = forms.ChoiceField(choices=REGION_CHOICE, widget=forms.Select(attrs={'title': 'Select Region',
                                                                            'style': 'width : 100%;',
                                                                            'id': 'widget_region',
                                                                            'onchange': 'region_changed();'}))

    countries = forms.ChoiceField(choices=COUNTRY_CHOICE, widget=forms.Select(attrs={'title': 'Select one country',
                                                                                    'style': 'width : 100%;',
                                                                                    'id': 'widget_country',
                                                                                    'onchange': 'country_changed();'}))

    companies = forms.ChoiceField(choices=COMPANY_CHOICE, widget=forms.Select(attrs={'title': 'Select one or more company',
                                                                                    'style': 'width : 100%;',
                                                                                     'id': 'widget_company',
                                                                                     'onchange': 'company_changed();'}))

    MAX_DATE = ValueMonthly.objects.values_list('val_month_date').latest('val_month_date')
    MIN_DATE = ValueMonthly.objects.values_list('val_month_date').latest('-val_month_date')
    for i in MAX_DATE:
        _max_date = str(i)
    for i in MIN_DATE:
        _min_date = str(i)

    period_min_mois = forms.DateField(required=True,
                                 widget=MonthPickerInput(
                                     format='%Y-%m',
                                     attrs={'id': 'widget_period_min_mois',
                                            'title': 'Period From',
                                            }),
                                 initial=_min_date,
                                 input_formats=['%Y-%m'],
                                 )

    period_max_mois = forms.DateField(required=True,
                                 widget=MonthPickerInput(
                                     format='%Y-%m',
                                     attrs={'id': 'widget_period_max_mois',
                                            'title': 'To'
                                            }),
                                 initial=_max_date,
                                 input_formats=['%Y-%m']
                                 )
    period_min_annee = forms.DateField(required=True,
                                 widget=YearPickerInput(
                                     format='%Y',
                                     attrs={'id': 'widget_period_min_annee',
                                            'title': 'Period From'
                                            }),
                                 initial=_min_date,
                                 input_formats=['%Y'],
                                 )

    period_max_annee = forms.DateField(required=True,
                                 widget=YearPickerInput(
                                     format='%Y',
                                     attrs={'id': 'widget_period_max_annee',
                                            'title': 'To'
                                            }),
                                 initial=_max_date,
                                 input_formats=['%Y']
                                 )
    count_result = forms.CharField(required=False, widget=forms.TextInput(attrs={'size': 5, 
                                                                        'title': 'count result',
                                                                         'id': 'widget_count_result'}))        