var ctx = $("#myChart").get(0).getContext("2d");
var myChart = null;
var url2 = null;
var url3 = null;
var dom_id = '';
$("#period_max_annee").hide();
$("#period_min_annee").hide();
var dom_id='';
var var_id = '';
var period_start = '';
var period_end = '';
var rgn_id = '';
var ctry_id = '';
var co_id = '';
var type_chart= $("input[type='radio'][name='format']:checked").val(); 
var type_value=$("input[type='radio'][name='period']:checked").val(); 

function get_count_result() {
    var url_count_result = "/count_result/?dom_id=" + dom_id + "&var_id=" + var_id + "&date_start=" + period_start + "&date_end=" + period_end
        + "&rgn_id=" + rgn_id + "&ctry_id=" + ctry_id + "&co_id=" + co_id+"&type_value="+type_value;
    $.ajax({
        url: url_count_result,
        success: function (data) {
            $.each(data, function (index, text) {
                $("#widget_count_result").val(text);
                if (!($("#widget_count_result").val() == '0')) {
                    $("#number_value").html(text + " values");
                } else if (!($("#widget_count_result").val() == '1')) {
                    $("#number_value").html(text + " value");
                } else {
                    $("#number_value").html(text + " values");
                }
            });
        }
    });
}

function domain_changed() {
    dom_id = $("#widget_domain").val();
    period_start = $("#widget_period_min").val();
    period_end = $("#widget_period_max").val();
    var_id = '';
    var type_value=$("input[type='radio'][name='period']:checked").val(); 
    var url_var = "/load_variable_by_type_value/?dom_id=" + dom_id+"&type_value="+type_value;
    $.ajax({
        url: url_var,
        success: function (data) {
            $("#widget_variable").empty();
            $.each(data, function (index, text) {
                $("#widget_variable").append(
                    $('<option></option>').val(index).html(text)
                );
            });
        }
    });
    get_count_result();
}

function variable_changed(){
    var_id = $("#widget_variable").val();
    var n=$("#widget_variable :selected").length;
    if (n > 6) {
        $('#aToManySelection').show();       
    } else {
        $('#aToManySelection').hide();
        get_count_result();
        if(co_id!=''){
            chart_update();
        }
    }    
}


function region_changed(){
    dom_id = $("#widget_domain").val();
    var_id ='';
    period_start = $("#widget_period_min").val();
    period_end = $("#widget_period_max").val();
    rgn_id = $("#widget_region").val();
    var url_ctry = "/load_country/?rgn_id=" + rgn_id;
     $.ajax({
            url: url_ctry,
            success: function (data) {
                $("#widget_country").empty();
                $("#widget_company").empty();
                $("#widget_country").append($('<option></option>').val('').html('select a country'));
                $.each(data, function (index, text) {
                    $("#widget_country").append(
                        $('<option></option>').val(index).html(text)
                    );
                });
            }
        });
    get_count_result();
}

 function country_changed() {
        dom_id = $("#widget_domain").val();
        var_id = $("#widget_variable").val();
        period_start = $("#widget_period_min").val();
        period_end = $("#widget_period_max").val();
        rgn_id = $("#widget_region").val();
        ctry_id = $("#widget_country").val();
        co_id = '';
        var url_company = "/load_company_by_ctry_id/?ctry_id=" + ctry_id;      
        $.ajax({
            url: url_company,
            success: function (data) {
                $("#widget_company").empty();
                $("#widget_company").append($('<option></option>').val('').html('select a company'));
                $.each(data, function (index, text) {
                    $("#widget_company").append(
                        $('<option></option>').val(index.split('_',1)).html(text)
                    );
                });
            }
        });
        get_count_result();
    }

    function company_changed() {
        var_id = $("#widget_variable").val();
        rgn_id = $("#widget_region").val(); 
        ctry_id = $("#widget_country").val();      
        chart_update();
        get_count_result();
    }

    function chart_update() {
        type_value=$("input[type='radio'][name='period']:checked").val(); 
        if(type_value=="mois"){
            period_start = $("#widget_period_min_mois").val();
            period_end = $("#widget_period_max_mois").val();
        }
        else if(type_value=="annee"){
            period_start = $("#widget_period_min_annee").val();
            period_end = $("#widget_period_max_annee").val();
        }
        type_chart= $("input[type='radio'][name='format']:checked").val(); 
        var_id = $("#widget_variable").val();
        co_id = $('#widget_company').val();
        url2 = '/chart_multiple_variables/json'+ "?var_id="+var_id+"&co_id="+co_id+"&period_start="+period_start+"&period_end="+period_end+"&type_value="+type_value;
            if (myChart != null) {
                myChart.destroy();
            }
            if (var_id==null || co_id==null){
                return ;
            }
            $.get(url2, function (data) {
                myChart = new Chart(ctx, {
                    type: type_chart,
                    data: data,
                    options: {
                        responsive: true,
                        legend: {
                            position: 'top'
                        },
                    }
                });
            });
        
        };

 
$("#type_chart").change(function(){ 
    chart_update();
});

$("#type_value").change(function(){
    $("#widget_domain").val("");
    $("#widget_variable").empty();
    type_value=$("input[type='radio'][name='period']:checked").val();
    if(type_value =="mois"){
        $("#period_max_annee").hide();
        $("#period_min_annee").hide();
        $("#period_max_mois").show();
        $("#period_min_mois").show();
    }
    else{
        $("#period_max_annee").show();
        $("#period_min_annee").show();
        $("#period_max_mois").hide();
        $("#period_min_mois").hide();
    }
});
 