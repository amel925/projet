# RailisaServersideChartJS
Railisa server-side ChartJs template for students.