from django.db import models
from django.contrib.auth.models import User as dj_user
#from django.contrib.gis.geos import GEOSGeometry
from django.contrib.sites.models import Site

# Create your models here.


class Region(models.Model):
    rgn_id = models.CharField(primary_key=True, max_length=5, db_column='rgn_id')
    rgn_name = models.CharField(max_length=1500, blank=True, null=True, db_column='rgn_name')

    def __str__(self):
        return self.dispaly_rgn_name

    def _get_dispaly_rgn_name(self):
        rnd = self.rgn_id.upper()
        rnd_good, rnd_wrong = rnd.split("_")
        return rnd_good + ' - ' + self.rgn_name.upper()

    dispaly_rgn_name = property(_get_dispaly_rgn_name)

    class Meta:
        ordering = ['rgn_id']
        managed = True
        db_table = 'Region'


class Country(models.Model):
    ctry_id = models.CharField(primary_key=True, max_length=5, db_column='ctry_id')
    ctry_name = models.CharField(max_length=1500, blank=True, null=True, db_column='ctry_name')
    rgn_id = models.ForeignKey(Region, on_delete=models.CASCADE, db_column='rgn_id')

    def __str__(self):
        return self.dispaly_ctry_name

    def rgn(self):
        return str(self.rgn_id_id)

    def _get_diaplay_ctry_name(self):
        rnd = str(self.rgn_id_id).upper()
        rnd_good, rnd_wrong = rnd.split("_")
        return rnd_good + ' - ' + str(self.ctry_name).upper() + ' - ' + str(self.ctry_id)[:2]

    dispaly_ctry_name = property(_get_diaplay_ctry_name)

    class Meta:
        ordering = ['rgn_id', 'ctry_name']
        managed = True
        db_table = 'Country'
        indexes = [
                models.Index(fields=['rgn_id', ]),
            ]


class Company(models.Model):
    co_id = models.IntegerField(primary_key=True, db_column='co_id')
    ctry_id = models.ForeignKey(Country, on_delete=models.CASCADE, db_column='ctry_id')
    co_cf_code = models.CharField(max_length=16, db_column='co_CF_code')
    co_full_name = models.CharField(max_length=1500, blank=True, null=True, db_column='co_full_name', db_index=True)
    co_alert_message = models.CharField(max_length=500, blank=True, null=True, db_column='co_alert_message')
    co_link_uic = models.IntegerField(db_column='co_link_uic')
    co_year_min = models.IntegerField(blank=True, null=True, db_column='co_year_min')
    co_year_max = models.IntegerField(blank=True, null=True, db_column='co_year_max')
    co_gps_string = models.CharField(max_length=256, blank=True, null=True, db_column='co_gps_string', db_index=True)

    def __str__(self):
        return self.display_co_name

    def _get_display_co_name(self):
        if self.co_year_min is None or self.co_year_max is None:
            data_period = ''
        else:
            data_period = ' (' + str(self.co_year_min) + ' to ' + str(self.co_year_max) + ')'

        return str(self.co_id) + '-' + str(self.ctry_id_id).upper()[:2] + ' - ' + str(self.co_cf_code).upper() + data_period

    # def _get_geom(self):
    #     geom = GEOSGeometry(self.co_gps_string, srid=4326).geojson
    #     return geom

    display_co_name = property(_get_display_co_name)
    #geom = property(_get_geom)

    class Meta:
        ordering = ['ctry_id', 'co_cf_code']
        managed = True
        db_table = 'Company'
        indexes = [
            models.Index(fields=['ctry_id', ]),
            models.Index(fields=['co_cf_code', ]),
        ]


class Domain(models.Model):
    dom_id = models.CharField(primary_key=True, max_length=5, db_column='dom_id')
    dom_name = models.CharField(max_length=50, blank=True, null=True, db_column='dom_name')

    def __str__(self):
        return self.dom_name

    class Meta:
        managed = True
        db_table = 'Domain'


class Unit(models.Model):
    unt_id = models.IntegerField(primary_key=True, db_column='unt_id')
    unt_name = models.CharField(max_length=1500, blank=True, null=True, db_column='unt_name')
    unt_symbol = models.CharField(max_length=5, db_column='unt_symbol')

    def __str__(self):
        return str(self.unt_id)

    class Meta:
        managed = True
        db_table = 'Unit'


class User(models.Model):
    usr_id = models.IntegerField(primary_key=True, db_column='usr_id')
    co_id = models.ForeignKey(Company, on_delete=models.CASCADE, db_column='co_id')  #
    usr_confidentiality = models.IntegerField(db_column='usr_confidentiality')
    usr_password = models.CharField(max_length=32, blank=True, null=True, db_column='usr_password')
    usr_username = models.CharField(max_length=32, blank=True, null=True, db_column='usr_username')
    usr_last_name = models.CharField(max_length=250, blank=True, null=True, db_column='usr_last_name')
    usr_first_name = models.CharField(max_length=250, blank=True, null=True, db_column='usr_first_name')
    usr_civility = models.CharField(max_length=1, db_column='usr_civility')
    usr_email = models.CharField(max_length=250, blank=True, null=True, db_column='usr_email')

    def __str__(self):
        return str(self.usr_id)

    class Meta:
        managed = True
        db_table = 'User'


class Variable(models.Model):
    var_id = models.IntegerField(primary_key=True, db_column='VAR_ID')
    unt_id = models.ForeignKey(Unit, on_delete=models.CASCADE, db_column='unt_id')
    dom_id = models.ForeignKey(Domain, on_delete=models.CASCADE, db_column='dom_id')
    var_full_name = models.CharField(max_length=250, blank=True, null=True, db_column='var_full_name')

    def __str__(self):
        var_name = str(self.var_full_name).strip(' ')
        len_var_name = 65  # avant 45
        if len(var_name) > len_var_name:
            var_name = str(var_name)[0:len_var_name - 3] + '...'
        return ' '.join([str(self.var_id).strip(' '), ':', var_name])


    def _get_display_var_full_name(self):
        var_name = str(self.var_full_name).strip(' ')
        len_var_name = 65
        if len(var_name) > len_var_name:
            var_name = str(var_name)[0:len_var_name - 3] + '...'
        return ' '.join([str(self.var_id).strip(' '), ':', var_name])

    def _get_display_unit(self):
        return self.unt_id_id

    variable = property(_get_display_var_full_name)
    unit = property(_get_display_unit)

    class Meta:
        managed = True
        db_table = 'Variable'
        ordering = ['var_id']
        indexes = [
            models.Index(fields=['dom_id', ]),
            models.Index(fields=['unt_id', ]),
        ]


class Value(models.Model):
    val_id = models.IntegerField(primary_key=True, db_column='VAL_ID')
    var_id = models.ForeignKey(Variable, on_delete=models.CASCADE, db_column='VAR_ID')
    co_id = models.ForeignKey(Company, on_delete=models.CASCADE, db_column='co_id')
    ctry_id = models.ForeignKey(Country, on_delete=models.CASCADE, db_column='ctry_id')
    val_data = models.CharField(max_length=24, blank=True, null=True, db_column='VAL_DATA')
    val_year = models.IntegerField(blank=True, null=True, db_column='val_year')
    val_confidentiality = models.IntegerField(blank=True, null=True, db_column='val_confidentiality')

    def __str__(self):
        return str(self.val_id)

    def _get_display_ctry_code(self):
        ctry_code = self.ctry_id_id
        return ctry_code

    def _get_vizibility(self):
        if self.val_confidentiality == 1:
            return 'Public'
        else:
            return 'Member'

    def _get_variable(self):
        return str(self.var_id) + ":" + self.var_id.var_full_name

    def _get_unit(self):
        return self.var_id.unt_id.unt_name

    def _get_country(self):
        return self.ctry_id.ctry_name

    def _get_region(self):
        return self.ctry_id.rgn_id.rgn_name

    def _get_company(self):
        return self.co_id.co_cf_code

    dispaly_ctry_code = property(_get_display_ctry_code)
    visibility = property(_get_vizibility)
    variable = property(_get_variable)
    unit = property(_get_unit)
    country = property(_get_country)
    region = property(_get_region)
    company = property(_get_company)

    class Meta:
        managed = True
        db_table = 'Value'
        indexes = [
            models.Index(fields=['var_id', ]),
            models.Index(fields=['co_id', ]),
            models.Index(fields=['ctry_id', ]),
            models.Index(fields=['val_year', ]),
            models.Index(fields=['val_confidentiality', ]),
        ]


class Selection(models.Model):
    slc_id = models.AutoField(primary_key=True)
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE, blank=True, null=True)
    uuid = models.CharField(max_length=50, blank=True, null=True)  # new field
    slc_date = models.DateTimeField(auto_now_add=True, db_column='slc_date')
    slc_year_start = models.CharField(max_length=4, blank=True, null=True, db_column='slc_year_start')
    slc_year_end = models.CharField(max_length=4, blank=True, null=True, db_column='slc_year_end')
    var_id = models.ForeignKey(Variable, on_delete=models.CASCADE, db_column='VAR_ID')
    co_id = models.ManyToManyField(Company, db_column='co_id')
    ctry_id = models.ManyToManyField(Country, db_column='ctry_id')
    country = models.CharField(max_length=100, null=True, blank=True, db_column='country',
                               verbose_name='country of user')
    city = models.CharField(max_length=100, null=True, blank=True, verbose_name='city of user')

    class Meta:
        managed = True
        ordering = ['-slc_date', ]
        get_latest_by = 'slc_date'
        indexes = [
            models.Index(fields=['uuid', ]),
            models.Index(fields=['user', ]),
            models.Index(fields=['var_id',]),
            models.Index(fields=['-slc_date', ]),
            models.Index(fields=['slc_year_start', ]),
            models.Index(fields=['slc_year_end', ]),
        ]

    def __str__(self):
        return ' '.join([str(self.user), str(self.var_id), str(self.slc_date)])

    # add by lucian
    def get_dom_id(self):
        return self.var_id.dom_id_id

    def get_selection(self):
        return ' '.join([str(self.user), str(self.var_id), str(self.slc_date)])

    dom_id = property(get_dom_id)
    selection = property(get_selection)


class Activity(models.Model):
    act_id = models.CharField(max_length=2, primary_key=True, db_column='act_id')
    act_name = models.CharField(max_length=1500, null=False, blank=True, db_column='act_name')

    class Meta:
        managed = True
        db_table = "Activity"
        verbose_name = 'Activity'
        verbose_name_plural = 'Activities'

    def __str__(self):
        return self.act_name


class CompanyActivity(models.Model):
    co_id = models.ForeignKey(Company, on_delete=models.CASCADE, db_column='co_id', related_name='cpyact1')
    act_id = models.ForeignKey(Activity, on_delete=models.CASCADE, db_column='act_id', related_name='cpyact2')

    class Meta:
        managed = True
        db_table = "Company_Activity"
        unique_together = (('co_id', 'act_id'),)
        verbose_name = 'Activity of Company'
        verbose_name_plural = 'Company activities'
        indexes = [
            models.Index(fields=['co_id',]),
            models.Index(fields=['act_id', ]),
            models.Index(fields=['co_id','act_id', ])
        ]

    def _get_activity(self):
        # act = Activity.objects.select_related().get(act_id=self.act_id)
        return self.act_id_id

    display_co_act_name = property(_get_activity)


class ValueMonthly(models.Model):
    MONTH_CHOICES = (
        ('M01', "January"),
        ('M02', "February"),
        ('M03', "March"),
        ('M04', "April"),
        ('M05', "May"),
        ('M06', "June"),
        ('M07', "July"),
        ('M08', "August"),
        ('M09', "September"),
        ('M10', "October"),
        ('M11', "November"),
        ('M12', "December"),
    )
    val_id = models.AutoField(primary_key=True, db_column='val_id')
    var_id = models.ForeignKey(Variable, on_delete=models.CASCADE, db_column='var_id')
    co_id = models.ForeignKey(Company, on_delete=models.CASCADE, db_column='co_id')
    ctry_id = models.ForeignKey(Country, on_delete=models.CASCADE, db_column='ctry_id')
    val_data = models.FloatField(blank=True, null=True, db_column='val_data')
    val_year = models.IntegerField(blank=True, null=True, db_column='val_year')
    val_month = models.CharField(max_length=3, blank=True, null=True, db_column='val_car', choices=MONTH_CHOICES)
    val_month_date = models.DateField(blank=True,null=True, db_column='val_date', verbose_name='Mounth Date')

    class Meta:
        managed = True
        db_table = 'ValueMonthly'
        indexes = [
            models.Index(fields=['var_id', ]),
            models.Index(fields=['co_id', ]),
            models.Index(fields=['ctry_id', ]),
            models.Index(fields=['val_year', ]),
            models.Index(fields=['val_month', ]),
        ]

    def __str__(self):
        return str(self.val_id)

