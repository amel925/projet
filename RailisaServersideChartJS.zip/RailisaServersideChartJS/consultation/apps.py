from django.apps import AppConfig


class ConsultationConfig(AppConfig):
    name = 'consultation'
